//Ce mastermind a �t� r�aliser par David De Groote (dadg@freesurf.ch), apprenti informaticien � l'EHMP
	//D�claration des fichiers a joindre avec mastermind.js
	document.write("<script language='JavaScript' src='constructeur.js'></script>");
	document.write("<script language='JavaScript' src='uneboule.js'></script>");
	document.write("<script language='JavaScript' src='initialisation.js'></script>");
	document.write("<script language='JavaScript' src='affichage.js'></script>");
	document.write("<script language='JavaScript' src='placer.js'></script>");
	document.write("<script language='JavaScript' src='effacer.js'></script>");
	document.write("<script language='JavaScript' src='verifier.js'></script>");
	document.write("<script language='JavaScript' src='soluce.js'></script>");
	document.write("<script language='JavaScript' src='recommencer.js'></script>");