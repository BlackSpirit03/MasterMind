Mastermind en javascript (jeux)-------------------------------
Url     : http://codes-sources.commentcamarche.net/source/16276-mastermind-en-javascript-jeuxAuteur  : dadgDate    : 05/08/2013
Licence :
=========

Ce document intitul� � Mastermind en javascript (jeux) � issu de CommentCaMarche
(codes-sources.commentcamarche.net) est mis � disposition sous les termes de
la licence Creative Commons. Vous pouvez copier, modifier des copies de cette
source, dans les conditions fix�es par la licence, tant que cette note
appara�t clairement.

Description :
=============

Mastermind en Javascript
<br />
<br />Ce Mastermind est enti&egrave;rement par
am&eacute;trable ! il est possible de choisir le nombre
<br />de couleurs (max 
6, mais possibilit&eacute; de rajouter des images pour en avoir plus et
<br />m
odifier une petite ligne de code), le nombre de colonnes et le 
<br />nombre de
 lignes.
<br />
<br />Cette version est la nouvelle version la programmation a
 &eacute;t&eacute; revue, il y'a de la POO.
<br />Les graphismes ont &eacute;ga
lement &eacute;t&eacute; revus (un grand merci &agrave; Bertrand Dubois qui me l
es a refait)
<br /><a name='source-exemple'></a><h2> Source / Exemple : </h2>

<br /><pre class='code' data-mode='basic'>
Tout est dans le zip !
</pre>
<br
 /><a name='conclusion'></a><h2> Conclusion : </h2>
<br />voil&agrave; Bon amu
sement
<br />
<br />Si vous avez des question ou des bugs a me signaler n'hesi
ter pas ! dadg@freesurf.ch
